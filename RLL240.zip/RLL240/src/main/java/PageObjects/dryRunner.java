package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class dryRunner {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
//		
//		WebDriver driver= new ChromeDriver();
//		
//		Login log= new Login();
//		log.init1(driver);
//		log.Lanuch_BooksWagon();
//		log.login("7731960046", "Bhavi@11");
//		log.myWishlist();
//		log.isclickable();
//		log.verifyOnWishlistPage();
		// System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
	        WebDriver driver = new ChromeDriver();

	        // Instantiate Page Objects
	        LoginPage loginPage = new LoginPage(driver);
	        MyWishlistPage wishlistPage = new MyWishlistPage(driver);

	        // Launch and login
	        loginPage.launchBooksWagon();
	        loginPage.login("7731960046", "Bhavi@11");

	        // Scroll and click the 7th card
	        loginPage.scrollAndClickOn7thCard();

	        // Add to Wishlist
	        loginPage.addToWishlist();

	        // Verify if the wishlist icon is clickable and user is on the Wishlist page
	        wishlistPage.clickMyWishlist();
	        wishlistPage.isWishlistIconClickable();
	        wishlistPage.verifyOnWishlistPage();
	        wishlistPage.clickAddButton();
	        wishlistPage.clickSubButton();
	        wishlistPage.removeItemAndVerify();

	        // Close the driver
	        driver.quit();

	}

}
