package PageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Login {
	WebDriver driver;
    By MyAccount=By.xpath("//span[contains(text(),\"My Account\")]");
	By loginButton = By.xpath("//div[@id='ctl00_divLogin']/a[@href='https://www.bookswagon.com/login']");
	By emailField = By.xpath("//input[@id=\"ctl00_phBody_SignIn_txtEmail\"]");
	By passwordField = By.xpath("//input[@id=\"ctl00_phBody_SignIn_txtPassword\"]");
	By submitButton = By.xpath("//a[@id=\"ctl00_phBody_SignIn_btnLogin\"]");
	
 
	
	
	public void init1(WebDriver driver) {
		this.driver = driver;	
 
	}
	public void Lanuch_BooksWagon() {
 
		driver.get("https://www.bookswagon.com/");
		driver.manage().window().maximize();
		
	}
	  
	
	public void login(String username, String password) throws InterruptedException {

		 WebElement profileIcon = driver.findElement(MyAccount);
		  
	        // Click on the profile icon
	        Actions actions = new Actions(driver);
	 
	        // Hover over the profile icon
	        actions.moveToElement(profileIcon).perform();
	        Thread.sleep(1000);
	        
	        WebElement Logint = driver.findElement(loginButton);
	        
	        
	        Logint.click();
	        
	        // Enter username inputField
	        WebElement usernameField = driver.findElement(emailField); 
	        usernameField.sendKeys(username);
	 
	        // Enter password
	        WebElement passwordInput = driver.findElement(passwordField);
	        passwordInput.sendKeys(password);
	        Thread.sleep(1000);
	        
	
	        // Click the login button
	        WebElement loginButton = driver.findElement(submitButton);
	        loginButton.click();
	        
	        
	        //
	        driver.findElement(By.xpath("//img[@id=\"ctl00_imglogo\"]")).click();
	        WebElement targetElement = driver.findElement(By.xpath("(//div[@class='card align-items-center'])[7]"));

	        // Scroll into view using JavaScript
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", targetElement);

	        // Wait for a short time to ensure the element is in view
	        Thread.sleep(1000);

	        // Click the target element
	        targetElement.click();
	        
	        WebElement targetElement2 = driver.findElement(By.xpath("//a[contains(@class, 'btn themeborder themecolor d-block mb-2') and contains(text(), 'Add to Wishlist')]"));
	        
	        targetElement2.click();
	 
	        
	    try {
	            Thread.sleep(3000); 
	            // Adjust based on your application's response time
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	}
	
	
	
	public void myWishlist() {
        // Click on My Wishlist icon
        WebElement wishlistIcon = driver.findElement(By.xpath(" //label[@id=\"ctl00_lblWishlistCount\"]")); 
        wishlistIcon.click();
    }
 
	
    public void isclickable() {
       
    	// Check if the wishlist icon is displayed and enabled
        WebElement wishlistIcon = driver.findElement(By.xpath(" //label[@id=\"ctl00_lblWishlistCount\"]")); 
        //assertTrue("Wishlist icon is not displayed", wishlistIcon.isDisplayed());
       // assertTrue("Wishlist icon is not clickable", wishlistIcon.isEnabled());
        
        if (wishlistIcon.isDisplayed()) {
            System.out.println("Wishlist icon is displayed.");
        } else {
            System.out.println("Wishlist icon is not displayed.");
        }
        
        if (wishlistIcon.isEnabled()) {
            System.out.println("Wishlist icon is clickable.");
        } else {
            System.out.println("Wishlist icon is not clickable.");
        }
 
        
    }
    public boolean verifyOnWishlistPage() {
        // Locate the element containing "My Wishlist" text
        WebElement wishlistHeader = driver.findElement(By.xpath("//h1[@class='m-0' and contains(text(), 'My Wishlist')]"));

        // Verify that the text is displayed correctly
        String actualText = wishlistHeader.getText();
        String expectedText = "My Wishlist";

        if (actualText.equals(expectedText)) {
            System.out.println("User is on the Wishlist page.");
            return true;
        } else {
            System.out.println("User is not on the Wishlist page.");
            return false;
        }
    }
    
    
    
    
    
    
}
	
	


