package PageObjects;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//import io.cucumber.messages.internal.com.google.protobuf.Duration;

public class MyWishlistPage {
	WebDriver driver;

    By wishlistIcon = By.xpath("//label[@id='ctl00_lblWishlistCount']");
    By wishlistHeader = By.xpath("//h1[@class='m-0' and contains(text(), 'My Wishlist')]");
    By addButton = By.xpath("//button[@id='add']");
    By subButton = By.xpath("//button[@id='sub']");
    By totalItemsText = By.xpath("//span[@id=\"ctl00_phBody_WishList_lvWishList_lblTotalQty\"]");
    By removeButton = By.xpath("//a[@id='ctl00_phBody_WishList_lvWishList_ctrl0_ImageButton1']");
    By noItemsMessage = By.xpath("//div[@class='no-items' and contains(text(), 'You do not have any item(s) in Wishlist')]");

    public MyWishlistPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickMyWishlist() {
        WebElement wishlistIconElement = driver.findElement(wishlistIcon);
        wishlistIconElement.click();
    }

    public boolean isWishlistIconClickable() {
        WebElement wishlistIconElement = driver.findElement(wishlistIcon);
        boolean isDisplayed = wishlistIconElement.isDisplayed();
        boolean isEnabled = wishlistIconElement.isEnabled();

        if (isDisplayed && isEnabled) {
            System.out.println("Wishlist icon is displayed and clickable.");
            return true;
        } else {
            System.out.println("Wishlist icon is either not displayed or not clickable.");
            return false;
        }
    }

    public boolean verifyOnWishlistPage() {
        // Verify that the user is on the Wishlist page
        WebElement wishlistHeaderElement = driver.findElement(wishlistHeader);
        String actualText = wishlistHeaderElement.getText();
        String expectedText = "My Wishlist";

        if (actualText.equals(expectedText)) {
            System.out.println("User is on the Wishlist page.");
            return true;
        } else {
            System.out.println("User is not on the Wishlist page.");
            return false;
        }
    }
    public void clickAddButton() {
        WebElement addButtonElement = driver.findElement(addButton);

        // Verify if the "+" button is displayed and enabled
        if (addButtonElement.isDisplayed() && addButtonElement.isEnabled()) {
            // Click the "+" button
            addButtonElement.click();
            System.out.println("Add button clicked successfully.");
        } else {
            if (!addButtonElement.isDisplayed()) {
                System.out.println("Add button is not displayed.");
            }
            if (!addButtonElement.isEnabled()) {
                System.out.println("Add button is not clickable.");
            }
            throw new RuntimeException("Add button is either not displayed or not clickable.");
        }
    }

    public void clickSubButton() {
        WebElement subButtonElement = driver.findElement(subButton);

        // Verify if the "-" button is displayed and enabled
        if (subButtonElement.isDisplayed() && subButtonElement.isEnabled()) {
            // Click the "-" button
            subButtonElement.click();
            System.out.println("Subtract button clicked successfully.");
        } else {
            if (!subButtonElement.isDisplayed()) {
                System.out.println("Subtract button is not displayed.");
            }
            if (!subButtonElement.isEnabled()) {
                System.out.println("Subtract button is not clickable.");
            }
            throw new RuntimeException("Subtract button is either not displayed or not clickable.");
        }
    }
    
    public void removeItemAndVerify() {
        // Click the remove button
        WebElement removeButtonElement = driver.findElement(removeButton);
        removeButtonElement.click();
        System.out.println("Remove button clicked successfully.");

        // Wait until the no items message is visible
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(noItemsMessage));

        // Verify that the no items message is displayed
        WebElement noItemsElement = driver.findElement(noItemsMessage);
        if (noItemsElement.isDisplayed()) {
            String actualText = noItemsElement.getText();
            String expectedText = "You do not have any item(s) in Wishlist";
            if (actualText.equals(expectedText)) {
                System.out.println("Item successfully removed from wishlist. Message displayed: " + actualText);
            } else {
                System.out.println("Message displayed is incorrect. Expected: " + expectedText + ", but found: " + actualText);
            }
        } else {
            System.out.println("No items message is not displayed.");
        }
    }
    
    
}
    
   
        
    

   

